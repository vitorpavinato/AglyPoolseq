### get GHNCD data

### station data
wget ftp://ftp.ncdc.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt \
-O /mnt/spicy_2/dest/ghcnd/ghcnd-stations.txt

cat /mnt/spicy_2/dest/ghcnd/ghcnd-stations.txt | sed -e 's/[[:space:]]\+/,/g' | cut -d',' -f1,2,3 > /mnt/spicy_2/dest/ghcnd/ghcnd-stations.csv

### weather data
nohup wget ftp://ftp.ncdc.noaa.gov/pub/data/ghcn/daily/ghcnd_all.tar.gz \
-O /mnt/spicy_2/dest/ghcnd/ghcnd_all.tar.gz &